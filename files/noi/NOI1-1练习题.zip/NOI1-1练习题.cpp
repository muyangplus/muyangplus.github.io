#include<iostream>
using namespace std;

int main(){
	int h,m,s;
	cin>>h>>m>>s;
	m=h*60+m;
	s=m*60+s;
	cout<<"�ٵ���"<<s<<"��"<<endl;
	return 0;
}



